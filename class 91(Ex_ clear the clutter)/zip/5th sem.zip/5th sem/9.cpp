#include <stdio.h>

struct Process {
    int id, bt, wt, tat;
};

void sort(struct Process p[], int n) {
    for (int i = 0; i < n - 1; i++)
        for (int j = 0; j < n - i - 1; j++)
            if (p[j].bt > p[j + 1].bt) {
                struct Process temp = p[j];
                p[j] = p[j + 1];
                p[j + 1] = temp;
            }
}

void calcTimes(struct Process p[], int n) {
    float awt = 0, atat = 0;
    p[0].wt = 0;
    for (int i = 1; i < n; i++)
        p[i].wt = p[i - 1].wt + p[i - 1].bt;
    
    for (int i = 0; i < n; i++) {
        p[i].tat = p[i].wt + p[i].bt;
        awt += p[i].wt;
        atat += p[i].tat;
    }
    printf("\nProcess  BT  WT  TAT\n");
    for (int i = 0; i < n; i++)
        printf("P%d       %d   %d   %d\n", p[i].id, p[i].bt, p[i].wt, p[i].tat);
    printf("\nAvg WT: %.2f  Avg TAT: %.2f\n", awt / n, atat / n);
}

void printGanttChart(struct Process p[], int n) {
    printf("\nGantt Chart:\n");
    for (int i = 0; i < n; i++)
        printf("| P%d ", p[i].id);
    printf("|\n");
}

int main() {
    int n;
    printf("Enter number of processes: ");
    scanf("%d", &n);
    struct Process p[n];
    
    for (int i = 0; i < n; i++) {
        p[i].id = i + 1;
        printf("Enter Burst Time for P%d: ", i + 1);
        scanf("%d", &p[i].bt);
    }
    
    sort(p, n);
    calcTimes(p, n);
    printGanttChart(p, n);
    return 0;
}

